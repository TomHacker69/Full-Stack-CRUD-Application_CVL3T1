import TaskManager from './components/TaskManager';
import './App.css';

function App() {
  return <TaskManager />;
}

export default App;